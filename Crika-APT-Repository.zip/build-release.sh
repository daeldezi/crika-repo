#!/bin/bash
set -euo pipefail

repo_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
pool_dir="$repo_dir/pool/main"
packages_file="$repo_dir/Packages"
packages_gz="$repo_dir/Packages.gz"
release_file="$repo_dir/Release"
tmp_packages="$TMPDIR/crika-packages-$$"

trap 'rm -f "$tmp_packages"' EXIT

mkdir -p "$pool_dir"
deb_count="$(find "$pool_dir" -type f -name '*.deb' | wc -l | tr -d ' ')"
if [[ "$deb_count" -gt 0 ]] && ! command -v dpkg-deb >/dev/null 2>&1 && ! command -v ar >/dev/null 2>&1; then
    echo "dpkg-deb or ar is required to index Crika packages." >&2
    exit 1
fi

if ! command -v md5 >/dev/null 2>&1 && ! command -v md5sum >/dev/null 2>&1; then
    echo "md5 or md5sum is required to generate repository checksums." >&2
    exit 1
fi

read_control() {
    local deb="$1"
    if command -v dpkg-deb >/dev/null 2>&1; then
        dpkg-deb -f "$deb"
        return
    fi

    local control_member
    control_member="$(ar t "$deb" | awk '/^control\.tar(\..*)?$/ { print; exit }')"
    if [[ -z "$control_member" ]]; then
        echo "No control archive found in package: $deb" >&2
        return 1
    fi
    ar p "$deb" "$control_member" | tar -xOf - ./control
}

control_field() {
    local control="$1"
    local field="$2"
    printf '%s\n' "$control" | awk -v field="$field" '
        index($0, field ":") == 1 {
            sub("^[^:]*:[[:space:]]*", "")
            print
            exit
        }
    '
}

md5_file() {
    if command -v md5sum >/dev/null 2>&1; then
        md5sum "$1" | awk '{ print $1 }'
    else
        md5 -q "$1"
    fi
}

: > "$tmp_packages"

while IFS= read -r deb; do
    control="$(read_control "$deb")"
    package="$(control_field "$control" Package)"
    version="$(control_field "$control" Version)"
    architecture="$(control_field "$control" Architecture)"
    size="$(wc -c < "$deb" | tr -d ' ')"
    filename="${deb#"$repo_dir"/}"

    if [[ -z "$package" || -z "$version" || -z "$architecture" ]]; then
        echo "Package metadata is incomplete: $deb" >&2
        exit 1
    fi

    printf '%s\nFilename: %s\nSize: %s\n\n' "$control" "$filename" "$size" >> "$tmp_packages"
done < <(find "$pool_dir" -type f -name '*.deb' -print | sort)

mv "$tmp_packages" "$packages_file"
gzip -n -c "$packages_file" > "$packages_gz"

packages_size="$(wc -c < "$packages_file" | tr -d ' ')"
packages_gz_size="$(wc -c < "$packages_gz" | tr -d ' ')"
packages_md5="$(md5_file "$packages_file")"
packages_gz_md5="$(md5_file "$packages_gz")"
packages_sha256="$(shasum -a 256 "$packages_file" | awk '{print $1}')"
packages_gz_sha256="$(shasum -a 256 "$packages_gz" | awk '{print $1}')"

cat > "$release_file" <<EOF
Origin: Crika
Label: Crika
Suite: stable
Codename: crika
Date: $(date -u '+%a, %d %b %Y %H:%M:%S GMT')
Architectures: iphoneos-arm iphoneos-arm64
Components: main
Acquire-By-Hash: no
Description: Crika package repository
MD5Sum:
 $packages_md5 $packages_size Packages
 $packages_gz_md5 $packages_gz_size Packages.gz
SHA256:
 $packages_sha256 $packages_size Packages
 $packages_gz_sha256 $packages_gz_size Packages.gz
EOF

echo "Generated Packages, Packages.gz, and unsigned Release."
