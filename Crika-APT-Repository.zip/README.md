# Crika APT repository

This directory is the static APT repository document root intended for `https://repo.getcrika.app/`.

The repository is flat. Add a release `.deb` to `pool/main/`, then regenerate the package indexes:

```sh
bash repo/build-release.sh
```

The script requires `gzip`, `shasum`, and `md5` (or `md5sum`). When `dpkg-deb` is unavailable, it reads Debian package metadata with `ar` and `tar`. It regenerates `Packages`, `Packages.gz`, and the checksum metadata in `Release`.

The `Release` file is unsigned. Before distributing packages, configure APT repository signing and publish the corresponding `InRelease` or `Release.gpg` file. Do not confuse an unsigned repository with a trusted package source.

The deployment workflow publishes the APT files at both the site root and `/repo/`, and includes a small landing page with Sileo and Zebra add-source links. The current public Pages site is `https://daeldezi.github.io/crika-repo/`. To use `repo.getcrika.app`, first point that subdomain's DNS record to GitHub Pages and configure the custom domain in the repository's Pages settings.

Add the repository to Sileo or Crika with:

```text
deb https://repo.getcrika.app/ ./
```
